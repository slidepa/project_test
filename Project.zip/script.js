function toggleMenu() {
    let menu = document.getElementById("menu");
    if (menu.classList.contains("hidden")) {
        menu.classList.remove("hidden");
    } else {
        menu.classList.add("hidden");
    }
}

// Показывать бургер-меню при малых экранах
window.addEventListener("resize", function() {
    let menu = document.getElementById("menu");
    let menuToggle = document.querySelector(".menu-toggle");
    if (window.innerWidth < 768) {
        menu.classList.add("hidden");
        menuToggle.style.display = "block";
    } else {
        menu.classList.remove("hidden");
        menuToggle.style.display = "none";
    }
});